<section id="main-content">
    <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Usuários(as) Cadastrados(as)</h3>            
        <table class="table table-striped" id="minhaTabela">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>CPF</th>
                    <th>Telefone</th>
                    <th>Acesso</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    include_once('conect/conect.php');
                    $select = "SELECT * FROM admin";
                    try{
                        $result = $conect->prepare($select);
                        $result-> execute();
                        $contar = $result-> rowCount();
                        if($contar>0){
                            while($show = $result ->FETCH(PDO::FETCH_OBJ)){
                                $id= $show->id;
                ?>
                <tr>
                    <td><?php echo $show->nome; ?></td>
                    <td><?php echo $show->email; ?></td>
                    <td><?php echo $show->cpf; ?></td>
                    <td><?php echo $show->fone; ?></td>
                    <td>
                        <?php 
                            if ($show->status == '0') {
                                echo '<button type="submit" class="btn btn-danger" name="botao1" ><i></i>Negado</button>';
                                $id = $show->id;
                            } else {
                                echo '<button type="submit" class="btn btn-success" name="botao2" ><i></i>Concedido</button>';
                                $id2 = $id;
                            }
                        ?>
                    </td>
                </tr>
                <?php
                    include_once('conect/conect.php');
                    if(isset($_POST['botao1'])){
                        $status = 1;
                        $update = "UPDATE admin SET status=:status WHERE id='$id1'";
                        try{
                            $result = $conect->prepare($update);
                            $result-> bindParam(':id',$id,PDO::PARAM_INT);
                            $result-> bindParam(':status',$status,PDO::PARAM_INT);
                            $result-> execute();
                            $contar = $result-> rowCount();
                            if($contar > 0){
                                header("Location: home.php?acao=adminTAB");
                            }else{ 
                                header("Location: home.php?acao=adminTAB");
                            }
                        }catch(PDOException $e){
                            echo "<b>ERRO DE PDO = </b>".$e->getMessage();
                        }
                    }
                ?>
                <?php
                            }
                        }else{
                            echo '<div class="alert alert-danger" role="alert">Não há dados!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO = </b>".$e->getMessage();
                    }
                ?>
            </tbody>
        </table>
    </section>
</section>











