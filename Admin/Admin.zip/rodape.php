<footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>MAGAMODA</strong>
        </p>
        <div class="credits">
        Sistema de autoria Magalhães.
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>



 <script src="lib/jquery/jquery.min.js"></script>
  <!-- js colocados no final do documento para que as páginas sejam carregadas mais rapidamente -->
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
<script src="lib/jquery.scrollTo.min.js"></script>
<script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
<script src="lib/jquery.sparkline.js"></script>
<!--script comum para todas as páginas-->
<script src="lib/common-scripts.js"></script>
<script type="text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
<script type="text/javascript" src="lib/gritter-conf.js"></script>
<!--script para o HEADER-->
<script src="lib/sparkline-chart.js"></script>
<script src="lib/zabuto_calendar.js"></script> 
  <!--common script for all pages-->
 


<link href="paginas/css/importante/jquery.dataTables.min.css" rel="stylesheet">
<script src="paginas/js/jquery.dataTables.min.js"></script> 
<script>
$(document).ready(function(){
    $('#minhaTabela').DataTable({
        "language": {
              "lengthMenu": "Mostrando _MENU_ registros por página",
              "zeroRecords": "Nada encontrado",
              "info": "Mostrando página _PAGE_ de _PAGES_",
              "infoEmpty": "Nenhum registro disponível",
              "infoFiltered": "(filtrado de _MAX_ registros no total)"
          }
      });
});
</script>


 





    </html>
    <body>