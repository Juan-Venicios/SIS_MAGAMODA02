<section id="main-content">
    <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Costureiras(os) Cadastradas(os)</h3>
        <a  style="margin-left:93%;" id="adicionarNOVO" type="button" class="btn btn-theme" href="home.php?acao=clientenovo"> <i class="fa fa-plus-square-o" 
        ></i>  Novo</a>
        <table class="table table-striped" id="minhaTabela">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>UF</th>
                    <th>Cidade</th>
                    <th>Bairro</th>
                    <th>CEP</th>
                    <th>Rua/Nº</th>
                    <th>CPF</th>
                    <th>Telefone</th>
                    <th>Deletar</th>
                    <th>Ver</th>
                    <th>Editar</th>           
                </tr>
            </thead>
            <tbody>
                <?php
                    include_once('conect/conect.php');
                    $select = "SELECT * FROM tb_cliente";
                    try{
                        $result = $conect->prepare($select);
                        $result-> execute();
                        $contar = $result-> rowCount();
                        if($contar>0){
                            while($show = $result ->FETCH(PDO::FETCH_OBJ)){
                ?>
                <tr>        
                    <td><?php echo $show->nome_cliente; ?></td>
                    <td><?php echo $show->email_cliente; ?></td>
                    <td><?php echo $show->uf_cliente;?></td>
                    <td><?php echo $show->cidade_cliente;?></td>
                    <td><?php echo $show->bairro_cliente;?></td>
                    <td><?php echo $show->cep_cliente; ?></td>
                    <td><?php echo $show->rua_cliente; ?></td>
                    <td><?php echo $show->cpf_cliente; ?></td>
                    <td><?php echo $show->telefone_cliente; ?></td>  
                    <td><a href="paginas/delete/deleteCliente.php?deletar=<?php echo $show->id_cliente?>" class="btn btn-danger" onclick="return confirm('Deseja realmente deletar o Registro')"><i class="fa fa-trash-o"></i></a></td>
                    <td><a href="home.php?acao=viscliente&viscliente=<?php echo $show->id_cliente;?>" class="btn btn-info"><i class="fa fa-sign-out"></i></a></td>
                    <td><a href="home.php?acao=cliente&upclientes=<?php echo $show->id_cliente;?>" class="btn btn-success"><i class="fa fa-pencil"></i></a></td>
                </tr>             
                <?php
                            }
                        }else{
                            echo '<div class="alert alert-danger" role="alert">Não há dados!</div>';
                        }
                    }catch(PDOException $e){
                        echo "<b>ERRO DE PDO = </b>".$e->getMessage();
                    }
                ?>
            </tbody>
        </table>
    </section>
</section>











