

   <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Modelos cadastrados</h3>

<a  style="margin-left:93%;" id="adicionarNOVO" type="button" class="btn btn-theme" href="home.php?acao=modeloCad"> <i class="fa fa-plus-square-o" 
       ></i>  Novo</a>
        

    
                          
    <table class="table table-striped" id="minhaTabela">
                                  <thead>
                                    <tr>
                                      <th>Nome</th>
                                      <th>IMG Modelo</th>
                                      <th>Código</th>
                                      <th>Qtd PP</th>
                                      <th>Qtd P</th>
                                      <th>Qtd M</th>
                                      <th>Qtd G</th>
                                      <th>Qtd GG</th>
                                      <th>Total</th>

                                      <th>Deletar</th>
                                      <th>Ver</th>
                                      <th>Editar</th>
                                      
                                    </tr>
                                  </thead>

                                  <tbody>
                                  <?php
                                   include_once('conect/conect.php'); 

                                $select = "SELECT * FROM tb_modelo";
                                try{
                                    $result = $conect->prepare($select);
                                    $result-> execute();
                                    $contar = $result-> rowCount();
                                    if($contar>0){
                                        while($show = $result ->FETCH(PDO::FETCH_OBJ)){
                                ?>
                                    <tr>
                                      <td><?php echo $show->nome_modelo; ?></td>
                                      <td><img src="img/<?php echo $show->img_modelo; ?>"width="75" height="75"></td>
                                      <td><?php echo $show->codigo_modelo; ?></td>
                                      <td><?php echo $show->tamPP; ?></td>
                                      <td><?php echo $show->tamP; ?></td>
                                      <td><?php echo $show->tamM; ?></td>
                                      <td><?php echo $show->tamG; ?></td>
                                      <td><?php echo $show->tamGG; ?></td>
                                      <td><?php echo $show->total_modelo; ?></td>


                                      <td><a href="paginas/delete/deleteModelo.php?deletar=<?php echo $show->id_modelo?>" class="btn btn-danger" onclick="return confirm('Deseja realmente deletar o Registro')"><i class="fa fa-trash-o"></i></a></td>

                                      <td><a href="home.php?acao=vismodelo&vismodelo=<?php echo $show->id_modelo;?>" class="btn btn-info"><i class="fa fa-sign-out"></i></a></td>

                                      <td><a href="home.php?acao=modelo&modelo=<?php echo $show->id_modelo;?>" class="btn btn-success"><i class="fa fa-pencil"></i></a></td>
                            
                                    </tr>
                                    <?php
                                        }
                                    }else{
                                        echo '<div class="alert alert-danger" role="alert">Não há dados!</div>';
                                    }
                                }catch(PDOException $e){
                                    echo "<b>ERRO DE PDO = </b>".$e->getMessage();
                                }
                            ?>
                                    </tbody>

     </table>

</div>

      </section>
    </section>











